﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Enums
{
    public enum BloodType
    {
        APositive = 1,
        ANegative = 2,
        BPositive = 3,
        BNegative = 4,
        ABPositive = 5,
        ABNegative = 6,
        OPositive = 7,
        ONegative = 8
    }
}
